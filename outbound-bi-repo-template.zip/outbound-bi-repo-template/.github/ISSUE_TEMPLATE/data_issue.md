---
name: Data or metric issue
about: Data or metric issue for Outbound Planning BI
title: ""
labels: ""
assignees: ""
---

Observed behavior:

Expected behavior:

Affected date range and outputs:

Source freshness:

Reproduction steps / query IDs:

Business impact:
