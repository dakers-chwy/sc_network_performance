---
name: Analysis request
about: Analysis request for Outbound Planning BI
title: ""
labels: ""
assignees: ""
---

Business question:

Decision supported:

Population and date range:

Required output and grain:

Sources / references:

Requested timing:
