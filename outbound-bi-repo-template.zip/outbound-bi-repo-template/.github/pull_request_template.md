## Business problem
What decision or metric needs this change?

## Change and resulting behavior
Explain the population, logic change, and downstream output.

## Validation evidence
- Input/output grain and row counts:
- Join fanout and duplicate checks:
- Matched/unmatched rating coverage:
- Denominator and exclusion reconciliation:
- Representative edge cases:
- Query IDs / run date / scenario version:

## Operational impact
Affected tables, Tableau workbooks, scheduled jobs, and rollback approach:

## Review checklist
- [ ] Scope and assumptions are documented.
- [ ] Validation supports the claimed result.
- [ ] Raw package data and credentials are excluded.
- [ ] Source changes and remaining limitations are stated.
